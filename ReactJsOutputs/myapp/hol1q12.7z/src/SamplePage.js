import React from "react";

const SamplePage = () => {
  return (
    <div>
      <h1>Welcome</h1>
      <p>Thanks for joining...</p>
      <p>What would you like to have</p>
      <ul>
        <li>Tea</li>
        <li>Coffee</li>
        <li>Snacks</li>
      </ul>
    </div>
  );
};

export default SamplePage;
