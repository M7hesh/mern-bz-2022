import React from "react";

const Footer = () => {
  return <footer>© 2022 Mahesh Mote development. All rights reserved.</footer>;
};

export default Footer;
