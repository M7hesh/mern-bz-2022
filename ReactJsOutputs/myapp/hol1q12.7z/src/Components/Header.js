import React from "react";

const Header = () => {
  return (
    <header>
      <nav>
        <div className="nav-logo">
          <img className="logo" src="./../react-logo.png" alt="logo"></img>
          <span>ReactFacts</span>
        </div>
        <h2 className="nav-h3">React Course - Project 1</h2>
      </nav>
    </header>
  );
};

export default Header;
