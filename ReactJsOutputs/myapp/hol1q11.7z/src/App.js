function App() {
  return (
    <div>
      <img src="./public/react-logo.png" width="40px" alt="logo" />
      <h1>React Facts</h1>
      <ul>
        <li>Released in 2013</li>
        <li>Created by Jordan Walke</li>
        <li>Maintained by Facebook</li>
      </ul>
    </div>
  );
}

export default App;
